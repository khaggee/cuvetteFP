import Response from '../models/Response.js'

// Submit a response to a form
export const submitResponse = async (req, res) => {
  try {
    const { formId } = req.params
    const { name, email, answers } = req.body

    const response = new Response({
      form: formId,
      name,
      email,
      answers,
    })

    await response.save()
    res.status(201).json({ message: 'Response submitted successfully', response })
  } catch (error) {
    res.status(500).json({ message: 'Error submitting response', error: error.message })
  }
}

// Get responses for a form
export const getResponses = async (req, res) => {
  try {
    const { formId } = req.params
    const responses = await Response.find({ form: formId })
    res.status(200).json({ responses })
  } catch (error) {
    res.status(500).json({ message: 'Error fetching responses', error: error.message })
  }
}
