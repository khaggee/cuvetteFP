import FlowSpace from '@/components/workspace/flow/flow-space'

export default function FlowPage() {
  return <FlowSpace />
}
