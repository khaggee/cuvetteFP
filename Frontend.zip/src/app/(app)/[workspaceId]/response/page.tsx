export default function ResponsePage() {
  return (
    <div>
      <h1>Flow Page</h1>
    </div>
  )
}
