import express from 'express'
import { createForm, getFormsByFolder, deleteForm } from '../controllers/formController.js'
import authMiddleware from '../middlewares/authMiddleware.js'

const router = express.Router()

router.post('/', authMiddleware, createForm)
router.get('/folder/:folderId', authMiddleware, getFormsByFolder)
router.delete('/:formId', authMiddleware, deleteForm)

export default router
