import mongoose from 'mongoose'

const responseSchema = new mongoose.Schema(
  {
    form: { type: mongoose.Schema.Types.ObjectId, ref: 'Form', required: true },
    name: { type: String, required: true },
    email: { type: String, required: true },
    answers: [
      {
        question: { type: String, required: true },
        answer: { type: String, required: true },
      },
    ],
  },
  { timestamps: true }
)

export default mongoose.model('Response', responseSchema)
