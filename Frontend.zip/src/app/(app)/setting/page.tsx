import SettingForm from '@/components/setting/setting-form'

export default function Setting() {
  return <SettingForm />
}
