import express from 'express'
import { submitResponse, getResponses } from '../controllers/responseController.js'

const router = express.Router()

router.post('/:formId', submitResponse)
router.get('/:formId', getResponses)

export default router
