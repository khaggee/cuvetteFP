import mongoose from 'mongoose'

const formSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    description: { type: String },
    questions: [
      {
        type: { type: String, required: true }, // e.g., text, number, dropdown
        label: { type: String, required: true },
        placeholder: { type: String },
        options: [String], // For dropdown, radio, checkbox
        required: { type: Boolean, default: false },
      },
    ],
    creator: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    folder: { type: mongoose.Schema.Types.ObjectId, ref: 'Folder' },
    sharedWith: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    theme: { type: String, default: 'light' },
    background: { type: String, default: 'default' },
  },
  { timestamps: true }
)

export default mongoose.model('Form', formSchema)
