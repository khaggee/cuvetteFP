import express from 'express'
import { createFolder, getFolders, deleteFolder } from '../controllers/folderController.js'
import authMiddleware from '../middlewares/authMiddleware.js'

const router = express.Router()

router.post('/', authMiddleware, createFolder)
router.get('/', authMiddleware, getFolders)
router.delete('/:folderId', authMiddleware, deleteFolder)

export default router
