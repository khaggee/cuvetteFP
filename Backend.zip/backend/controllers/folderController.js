import Folder from '../models/Folder.js'
import Form from '../models/Form.js' // Ensure the Form model is imported for deleting forms

// Create a new folder
export const createFolder = async (req, res) => {
  try {
    const { name } = req.body
    const folder = new Folder({
      name,
      creator: req.user.id,
    })

    await folder.save()
    res.status(201).json({ folder })
  } catch (error) {
    res.status(500).json({ message: 'Error creating folder', error: error.message })
  }
}

// Get all folders for a user
export const getFolders = async (req, res) => {
  try {
    const folders = await Folder.find({ creator: req.user.id }).populate('forms')
    res.status(200).json({ folders })
  } catch (error) {
    res.status(500).json({ message: 'Error fetching folders', error: error.message })
  }
}

// Delete a folder and its forms
export const deleteFolder = async (req, res) => {
  try {
    const { folderId } = req.params
    const folder = await Folder.findById(folderId)

    if (!folder || folder.creator.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Unauthorized' })
    }

    await Folder.findByIdAndDelete(folderId)
    await Form.deleteMany({ folder: folderId }) // Delete all forms in the folder

    res.status(200).json({ message: 'Folder deleted successfully' })
  } catch (error) {
    res.status(500).json({ message: 'Error deleting folder', error: error.message })
  }
}
