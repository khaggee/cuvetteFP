import Form from '../models/Form.js'
import Folder from '../models/Folder.js'
import { formatDistanceToNow } from 'date-fns'
import Response from '../models/Response.js'
// Create a new form
import mongoose from 'mongoose';

export const createForm = async (req, res) => {
  try {
    const { name, description, questions, folderId } = req.body;

    // Validate folderId and convert to ObjectId
    if (!mongoose.Types.ObjectId.isValid(folderId)) {
      return res.status(400).json({ message: 'Invalid folderId' });
    }

    const form = new Form({
      name,
      description,
      questions,
      creator: req.user.id,
      folder: mongoose.Types.ObjectId(folderId), // Convert to ObjectId
    });

    await form.save();

    // Add form to folder
    if (folderId) {
      const folder = await Folder.findById(folderId);
      if (!folder) {
        return res.status(404).json({ message: 'Folder not found' });
      }
      folder.forms.push(form._id);
      await folder.save();
    }

    res.status(201).json({ form });
  } catch (error) {
    res.status(500).json({ message: 'Error creating form', error: error.message });
  }
};

// Get all forms in a folder
export const getFormsByFolder = async (req, res) => {
  try {
    const { folderId } = req.params

    // Fetch forms with only required fields
    const forms = await Form.find({ folder: folderId, creator: req.user.id })
      .select('name _id createdAt') // Fetch only name, id (_id), and createdAt
      .lean() // Convert Mongoose documents to plain JS objects for better performance

    // Enhance each form with the number of submissions and relative time
    const enhancedForms = await Promise.all(
      forms.map(async (form) => {
        const submissionCount = await Response.countDocuments({ form: form._id }) // Count submissions for the form
        return {
          id: form._id,
          name: form.name,
          submissions: submissionCount,
          createdAt: formatDistanceToNow(new Date(form.createdAt), { addSuffix: true }), // Relative time
        }
      })
    )

    res.status(200).json({ forms: enhancedForms })
  } catch (error) {
    res.status(500).json({ message: 'Error fetching forms', error: error.message })
  }
}

// Delete a form
export const deleteForm = async (req, res) => {
  try {
    const { formId } = req.params
    const form = await Form.findById(formId)
    if (!form || form.creator.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Unauthorized' })
    }

    await Form.findByIdAndDelete(formId)

    // Remove from folder
    if (form.folder) {
      const folder = await Folder.findById(form.folder)
      folder.forms = folder.forms.filter((id) => id.toString() !== formId)
      await folder.save()
    }

    res.status(200).json({ message: 'Form deleted successfully' })
  } catch (error) {
    res.status(500).json({ message: 'Error deleting form', error: error.message })
  }
}
